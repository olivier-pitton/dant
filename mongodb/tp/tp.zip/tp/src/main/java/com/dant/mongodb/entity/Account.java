package com.dant.mongodb.entity;

import java.io.Serializable;

public class Account implements Serializable {


	public Account(String email) {
	}

}
