package com.dant.mongodb.entity;

import java.io.Serializable;

/**
 * Created by pitton on 2017-02-21.
 */

public class Account implements Serializable {

	private String email;

	private long created = System.currentTimeMillis();

	public Account(String email) {
		this.email = email;
	}
}
