package com.dant.mongodb.business;

import com.dant.mongodb.entity.Account;

import java.util.List;

/**
 * Created by pitton on 2017-02-21.
 */
public class AccountServiceImpl implements AccountService {

	public Account save(String email) {
		return null;
	}

	public Account find(String email) {
		return null;
	}

	public List<Account> findAll() {
		return null;
	}

	public void remove(String email) {
	}
}
