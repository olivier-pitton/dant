package com.dant.mongodb.business;

import com.dant.mongodb.entity.Account;
import com.dant.mongodb.util.MongoUtil;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.Query;

import java.util.List;

/**
 * Created by pitton on 2017-02-21.
 */
public class AccountServiceImpl implements AccountService {

	private final Datastore datastore;

	public AccountServiceImpl(Datastore datastore) {
		this.datastore = datastore;
	}

	public Account save(String email) {
		return null;
	}

	public Account find(String email) {
		return null;
	}

	public List<Account> findAll() {
		return null;
	}

	public void remove(String email) {
	}
}
