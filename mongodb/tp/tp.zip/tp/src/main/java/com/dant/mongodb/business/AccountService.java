package com.dant.mongodb.business;

import com.dant.mongodb.entity.Account;

import java.util.List;

/**
 * Un service qui permet de manipuler les Account
 * Created by pitton on 2017-02-21.
 */
public interface AccountService {

	Account save(String email);

	Account find(String email);

	List<Account> findAll();

	void remove(String email);

}
