package com.dant.mongodb.util;

import com.mongodb.MongoClient;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Morphia;

/**
 * Created by pitton on 2017-02-21.
 */
public class MongoUtil {

	public static final Datastore ds = Init.instance();

	private static class Init {

		public static Datastore instance() {
			Morphia morphia = new Morphia();
			morphia.mapPackage("com.dant.mongodb.entity");
			Datastore datastore = morphia.createDatastore(new MongoClient(), "ntw");
			datastore.ensureIndexes();
			return datastore;
		}
	}

	private MongoUtil() {}
}
