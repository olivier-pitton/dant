package com.dant.mongodb;

import com.dant.mongodb.business.AccountService;
import com.dant.mongodb.business.AccountServiceImpl;
import com.dant.mongodb.entity.Account;
import com.dant.mongodb.util.MongoUtil;
import org.testng.annotations.Test;

import java.util.List;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertNull;

/**
 * Created by pitton on 2017-02-21.
 */
@Test
public class AccountServiceTest {

	public void testPrimaryNode() {
		AccountService accountService = new AccountServiceImpl(MongoUtil.getPrimaryNode());

		String email = "olivier.pitton@gmail.com";
		Account saveAccount = accountService.save(email);
		assertNotNull(saveAccount);
		assertEquals(saveAccount, accountService.find(email));

		List<Account> accountList = accountService.findAll();
		assertEquals(accountList.size(), 1);
		assertEquals(saveAccount, accountList.get(0));

		accountService.remove(email);
		assertNull(accountService.find(email));
	}

}
