package com.dant.storage;

import com.dant.chunk.ChunkFactory;
import com.dant.strategy.ChunkStrategy;
import com.mongodb.ServerAddress;

public class ChunkStorageImplTest extends AChunkStorage {

  @Override
  protected ChunkStorage createStorage(ChunkStorageFactory factory, ChunkStrategy strategy, ServerAddress... addresses) {
    return factory.create(new ChunkFactory().create().getClass(), addresses[0]);
  }

}
