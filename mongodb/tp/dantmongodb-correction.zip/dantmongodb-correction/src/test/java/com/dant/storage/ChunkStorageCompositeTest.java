package com.dant.storage;

import com.dant.chunk.Chunk;
import com.dant.chunk.ChunkFactory;
import com.dant.strategy.ChunkStrategy;
import com.dant.strategy.HashStrategy;
import com.dant.strategy.RoundRobinStrategy;
import com.mongodb.ServerAddress;
import org.testng.annotations.Test;

import java.net.UnknownHostException;
import java.util.List;

import static org.testng.Assert.assertEquals;

@Test
public class ChunkStorageCompositeTest extends AChunkStorage {

	@Override
	protected ChunkStorage createStorage(ChunkStorageFactory factory, ChunkStrategy strategy, ServerAddress... addresses) {
		return factory.createComposite(new ChunkFactory().create().getClass(), strategy, addresses);
	}

	public final void testHash() throws IllegalStateException, UnknownHostException {
		ChunkStrategy strategy = new HashStrategy();
		final ChunkStorageFactory factory = new ChunkStorageFactory();
		// On met a sur un serveur et b sur un autre car "a" % 2 = 1 et "b"%2 = 0
		String a = "a";
		String b = "b";
		ChunkStorage storage = createStorage(factory, strategy, new ServerAddress("localhost", 27017), new ServerAddress("localhost", 27018));
		for (int i = 0; i < 10; i++) {
			storage.add(createChunk(a, i, 9));
			storage.add(createChunk(b, i, 9));
		}
		storage.close();
		ChunkStorage first = createStorage(factory, strategy, new ServerAddress("localhost", 27017));
		assertEquals(0, first.find(a).size());
		List<Chunk> find = first.find(b);
		assertEquals(10, find.size());
		first.close();

		ChunkStorage second = createStorage(factory, strategy, new ServerAddress("localhost", 27018));
		assertEquals(0, second.find(b).size());
		List<Chunk> find2 = second.find(a);
		assertEquals(10, find2.size());
		second.close();
	}

	public final void testRR() throws IllegalStateException, UnknownHostException {
		final ChunkStorageFactory factory = new ChunkStorageFactory();
		ChunkStrategy strategy = new RoundRobinStrategy();
		// Si on met 10 objets, on doit en avoir 5 sur chaque serveur
		String a = "value";
		ChunkStorage storage = createStorage(factory, strategy, new ServerAddress("localhost", 27017), new ServerAddress("localhost", 27018));
		for (int i = 0; i < 10; i++) {
			storage.add(createChunk(a, i, 9));
		}
		storage.close();

		ChunkStorage first = createStorage(factory, strategy, new ServerAddress("localhost", 27017));
		assertEquals(5, first.find(a).size());
		first.close();


		ChunkStorage second = createStorage(factory, strategy, new ServerAddress("localhost", 27018));
		assertEquals(5, second.find(a).size());
		second.close();
	}
}
