package com.dant.storage;

import com.dant.strategy.ChunkStrategy;
import com.mongodb.ServerAddress;

public class ChunkFSStorageTest extends AChunkStorage {

	@Override
	protected ChunkStorage createStorage(ChunkStorageFactory factory, ChunkStrategy strategy, ServerAddress... address) {
		return factory.createFS(address[0]);
	}

}
