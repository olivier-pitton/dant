package com.dant.strategy;


import com.dant.chunk.Chunk;
import com.dant.storage.ChunkStorage;

import java.util.List;

public class RoundRobinStrategy implements ChunkStrategy {

  private int cpt = 0;
  

  @Override
  public boolean isRandom() {
    return true;
  }
  
  @Override
  public <T extends Chunk> ChunkStorage select(String chunkName, List<ChunkStorage<T>> servers) {
    int next = cpt % servers.size();
    ++cpt;
    return servers.get(next);
  }

}
