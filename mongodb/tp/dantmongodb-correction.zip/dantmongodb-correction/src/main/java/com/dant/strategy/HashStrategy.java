package com.dant.strategy;


import com.dant.chunk.Chunk;
import com.dant.storage.ChunkStorage;

import java.util.List;

public class HashStrategy implements ChunkStrategy {

  public HashStrategy() {
  }

  @Override
  public boolean isRandom() {
    return false;
  }

  @Override
  public <T extends Chunk> ChunkStorage select(String chunkName, List<ChunkStorage<T>> servers) {
    int hash = Math.abs(chunkName.hashCode()) % servers.size();
    return servers.get(hash);
  }

}
