package com.dant.storage;

import com.dant.chunk.Chunk;
import com.mongodb.MongoClient;
import com.mongodb.ServerAddress;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Morphia;

import java.util.List;

public class ChunkStorageImpl<T extends Chunk> implements ChunkStorage<T> {

	static private final String DB_NAME = "chunk";

	private final Datastore datastore;
	private final Class<T> entityClass;

	public ChunkStorageImpl(Class<T> entityClass, ServerAddress addr) {
		if (addr == null) {
			throw new IllegalArgumentException("Need at least one address");
		}
		MongoClient client = new MongoClient(addr);
		datastore = new Morphia().createDatastore(client, DB_NAME);
		this.entityClass = entityClass;
		System.err.println("Node " + toString() + " is starting");
	}

	@Override
	public synchronized void close() throws IllegalStateException {
		System.err.println("Node " + toString() + " is closing");
		datastore.getMongo().close();
	}

	@Override
	public void add(T chunk) {
		System.err.println("[" + toString() + "] is saving : " + chunk);
		datastore.save(chunk);
	}


	@Override
	public void add(List<T> chunks) {
		System.err.println("[" + toString() + "] is saving : " + chunks);
		datastore.save(chunks);
	}

	@Override
	public void remove(T chunk) {
		System.err.println("[" + toString() + "] is removing : " + chunk);
		datastore.delete(chunk);
	}

	@Override
	public long chunks() {
		return datastore.getCount(entityClass);
	}

	@Override
	public T find(String name, long id) {
		return datastore.createQuery(entityClass).filter("name", name).filter("id", id).get();
	}

	@Override
	public List<T> find(String name) {
		return datastore.createQuery(entityClass).filter("name", name).asList();
	}


	@Override
	public String toString() {
		ServerAddress address = datastore.getMongo().getAddress();
		return address.getHost() + ":" + address.getPort();
	}
}
