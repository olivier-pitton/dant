package com.dant.storage;

import com.dant.chunk.Chunk;
import com.dant.strategy.ChunkStrategy;
import com.mongodb.ServerAddress;

import java.util.ArrayList;
import java.util.List;

public class ChunkStorageComposite<T extends Chunk> implements ChunkStorage<T> {

	private List<ChunkStorage<T>> storages;
	private ChunkStrategy strategy;

	public ChunkStorageComposite(Class<T> clazz, ChunkStrategy strategy, ServerAddress... servers) {
		this.strategy = strategy;
		if (servers == null) {
			throw new IllegalArgumentException("Need at least one address");
		}
		ChunkStorageFactory factory = new ChunkStorageFactory();
		storages = new ArrayList<>();
		for (ServerAddress serv : servers) {
			ChunkStorage create = factory.create(clazz, serv);
			storages.add(create);
		}
	}


	@Override
	public synchronized void close() throws IllegalStateException {
		for (ChunkStorage st : storages) {
			st.close();
		}
		storages.clear();
	}

	@Override
	public void add(List<T> chunks) {
		for (Chunk chunk : chunks) {
			ChunkStorage select = strategy.select(chunk.getName(), storages);
			select.add(chunk);
		}
	}

	@Override
	public void remove(T chunk) {
		if (strategy.isRandom() == false) {
			ChunkStorage select = strategy.select(chunk.getName(), storages);
			select.remove(chunk);
			return;
		}
		for (ChunkStorage st : storages) {
			st.remove(chunk);
		}
	}

	@Override
	public long chunks() {
		long size = 0;
		for (ChunkStorage st : storages) {
			size += st.chunks();
		}
		return size;
	}

	@Override
	public void add(T chunk) {
		ChunkStorage select = strategy.select(chunk.getName(), storages);
		select.add(chunk);
	}

	@Override
	public T find(String name, long id) {
		if (strategy.isRandom() == false) {
			ChunkStorage<T> select = strategy.select(name, storages);
			return select.find(name, id);
		}
		for (ChunkStorage<T> st : storages) {
			T find = st.find(name, id);
			if (find != null) {
				return find;
			}
		}
		return null;
	}

	@Override
	public List<T> find(String name) {
		if (strategy.isRandom() == false) {
			ChunkStorage select = strategy.select(name, storages);
			return select.find(name);
		}
		List<T> chunks = new ArrayList<>();
		for (ChunkStorage st : storages) {
			List<T> find = st.find(name);
			chunks.addAll(find);
		}
		return chunks;
	}

	@Override
	public final String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Composite : ");
		sb.append(storages);
		return sb.toString();
	}
}
