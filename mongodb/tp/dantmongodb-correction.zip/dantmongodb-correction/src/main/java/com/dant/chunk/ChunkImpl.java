package com.dant.chunk;

import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Indexed;

@Entity("chunk")
public class ChunkImpl implements Chunk {

	private static final long serialVersionUID = 1L;

	@Id
	private ObjectId objectId;

	private long id;

	private String name;

	private long maxId;
	private byte[] content;

	public ChunkImpl() {
	}

	public ChunkImpl(String name, long id, long maxValue, byte[] content) {
		this.name = name;
		this.id = id;
		this.maxId = maxValue;
		this.content = content;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getMaxId() {
		return this.maxId;
	}

	public void setMaxId(long maxValue) {
		this.maxId = maxValue;
	}

	public byte[] getContent() {
		return this.content;
	}

	public void setContent(byte[] content) {
		this.content = content;
	}

	public ObjectId getObjectId() {
		return objectId;
	}

	public void setObjectId(ObjectId objectId) {
		this.objectId = objectId;
	}
	@Override
	public int compareTo(Chunk o) {
		int val = name.compareTo(o.getName());
		// On tri dans le sens inverse (1 est plus grand que 2)
		return (val != 0) ? val : (int) (o.getId() - id);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (this.id ^ (this.id >>> 32));
		result = prime * result + ((this.name == null) ? 0 : this.name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof ChunkImpl))
			return false;
		ChunkImpl other = (ChunkImpl) obj;
		if (this.id != other.id)
			return false;
		if (this.name == null) {
			if (other.name != null)
				return false;
		} else if (!this.name.equals(other.name))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return name + "@" + id;
	}

}
