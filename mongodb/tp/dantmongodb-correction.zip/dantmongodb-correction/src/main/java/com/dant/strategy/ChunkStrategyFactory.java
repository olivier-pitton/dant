package com.dant.strategy;

/**
 * Une factory de création de stratégies
 * 
 * @author pitton
 * 
 */
public class ChunkStrategyFactory {

  public ChunkStrategy createRR() {
    return new RoundRobinStrategy();
  }

  public ChunkStrategy createHash() {
    return new HashStrategy();
  }

}
