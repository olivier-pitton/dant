package com.dant.storage;

import com.dant.chunk.Chunk;
import com.dant.chunk.ChunkBuilder;
import com.mongodb.MongoClient;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.GridFSFindIterable;
import com.mongodb.client.gridfs.model.GridFSFile;
import com.mongodb.client.gridfs.model.GridFSUploadOptions;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;

public class ChunkStorageFS<T extends Chunk> implements ChunkStorage<T> {

	static private final String DB_NAME = "chunk";

	private GridFSBucket gridfs;
	private final MongoClient mongoClient;

	public ChunkStorageFS(ServerAddress addr) {
		if (addr == null) {
			throw new IllegalArgumentException("Need at least one address");
		}
		mongoClient = new MongoClient(addr);
		this.gridfs = GridFSBuckets.create(mongoClient.getDatabase(DB_NAME));
		System.err.println("FS Node " + toString() + " is starting");
	}

	@Override
	public synchronized void close() throws IllegalStateException {
		System.err.println("FS Node " + toString() + " is closing");
		mongoClient.close();
		gridfs = null;
	}

	@Override
	public void add(T chunk) {
		GridFSUploadOptions options = new GridFSUploadOptions()
				.chunkSizeBytes(chunk.getContent().length)
				.metadata(new Document("name", chunk.getName()).append("id", chunk.getId()).append("maxId", chunk.getMaxId()));
		ObjectId objectId = gridfs.uploadFromStream(chunk.getName(), new ByteArrayInputStream(chunk.getContent()), options);
		chunk.setObjectId(objectId);
	}

	@Override
	public void add(List<T> chunks) {
		for (T chunk : chunks) {
			add(chunk);
		}
	}

	@Override
	public void remove(T chunk) {
		this.gridfs.delete(chunk.getObjectId());
	}

	@Override
	public T find(String name, long id) {
		MongoCursor<GridFSFile> iterator = gridfs.find(and(eq("metadata.name", name), eq("metadata.id", id))).limit(1).iterator();
		if (iterator.hasNext()) {
			GridFSFile file = iterator.next();
			return fromFile(file);
		}
		return null;
	}

	@Override
	public List<T> find(String name) {
		List<T> res = new ArrayList<T>();
		MongoCursor<GridFSFile> iterator = gridfs.find(eq("metadata.name", name)).iterator();
		while (iterator.hasNext()) {
			GridFSFile file = iterator.next();
			res.add(fromFile(file));
		}
		return res;
	}

	@Override
	public long chunks() {
		long nbChunks = 0L;
		GridFSFindIterable gridFSFiles = gridfs.find();
		for (GridFSFile file : gridFSFiles) {
			nbChunks++;
		}
		return nbChunks;
	}

	private T fromFile(GridFSFile file) {
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		gridfs.downloadToStream(file.getFilename(), stream);

		Document metadata = file.getMetadata();
		return (T) new ChunkBuilder().setObjectId(file.getObjectId())
				.setContent(stream.toByteArray())
				.setIds(metadata.getLong("id"), metadata.getLong("maxId"))
				.setName(file.getFilename()).build();
	}

	@Override
	public String toString() {
		ServerAddress address = mongoClient.getAddress();
		return address.getHost() + ":" + address.getPort();
	}

}
