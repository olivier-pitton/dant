package com.dant.storage;


import com.dant.chunk.Chunk;
import com.dant.strategy.ChunkStrategy;
import com.mongodb.ServerAddress;

/**
 * Une factory de création de ChunkStorage.
 * @author pitton
 *
 */
public class ChunkStorageFactory {

	public ChunkStorageFactory() {
	}

	public <T extends Chunk> ChunkStorage create(Class<T> entityClass, ServerAddress address) {
		return new ChunkStorageImpl(entityClass, address);
	}

	public <T extends Chunk> ChunkStorage createComposite(Class<T> clazz, ChunkStrategy st, ServerAddress... address) {
		return new ChunkStorageComposite(clazz, st, address);
	}

	public ChunkStorage createFS(ServerAddress address) {
		return new ChunkStorageFS(address);
	}

}
