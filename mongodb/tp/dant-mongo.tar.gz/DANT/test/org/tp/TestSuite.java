package org.tp;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import org.tp.chunk.ChunkTest;
import org.tp.storage.ChunkFSStorageTest;
import org.tp.storage.ChunkStorageCompositeTest;
import org.tp.storage.ChunkStorageImplTest;
import org.tp.strategy.HashStrategyTest;
import org.tp.strategy.RoundRobinStrategyTest;

@RunWith(Suite.class)
@SuiteClasses({
  ChunkTest.class,
  ChunkStorageImplTest.class,
  ChunkStorageCompositeTest.class,
  RoundRobinStrategyTest.class,
  HashStrategyTest.class,
  ChunkFSStorageTest.class
})
public class TestSuite {

}
