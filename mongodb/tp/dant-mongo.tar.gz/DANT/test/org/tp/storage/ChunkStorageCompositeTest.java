package org.tp.storage;

import static org.junit.Assert.assertEquals;

import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.tp.chunk.Chunk;
import org.tp.strategy.ChunkStrategy;
import org.tp.strategy.ChunkStrategyFactory;

import com.mongodb.ServerAddress;

@RunWith(Parameterized.class)
public class ChunkStorageCompositeTest extends AChunkStorage {

  @Parameters
  static public Collection<Object[]> parameters() {
    ChunkStrategyFactory fact = new ChunkStrategyFactory();
    return Arrays.<Object[]> asList(new Object[] { fact.createHash() } , new Object[] { fact.createRR() });
  }

  final private ChunkStrategy strategy;

  public ChunkStorageCompositeTest(ChunkStrategy st) {
    this.strategy = st;
  }

  @Override
  protected ChunkStorage createStorage(ChunkStorageFactory factory) {
    return factory.createComposite(strategy);
  }

  @Test(timeout = 10000L)
  public final void testHash() throws IllegalStateException, UnknownHostException {
    final ChunkStorageFactory factory = new ChunkStorageFactory();
    if (strategy.isRandom()) {
      // On teste uniquement le Hash
      return;
    }
    // On met a sur un serveur et b sur un autre car "a" % 2 = 1 et "b"%2 = 0
    String a = "a";
    String b = "b";
    Chunk aChunk = createChunk(a);
    Chunk bChunk = createChunk(b);
    String col_name = "dummy_test";
    ChunkStorage storage = createStorage(factory).start(col_name, new ServerAddress("localhost", 27017), new ServerAddress("localhost", 27018));
    for (int i = 0; i < 10; i++) {
      storage.add(aChunk);
      storage.add(bChunk);
    }
    storage.close();
    ChunkStorage first = factory.create().start(col_name, new ServerAddress("localhost", 27017));
    assertEquals(0, first.find(a).size());
    List<Chunk> find = first.find(b);
    assertEquals(10, find.size());
    first.remove(bChunk);
    first.close();

    ChunkStorage second = factory.create().start(col_name, new ServerAddress("localhost", 27018));
    assertEquals(0, second.find(b).size());
    List<Chunk> find2 = second.find(a);
    assertEquals(10, find2.size());
    second.remove(aChunk);
    second.close();
  }

  @Test(timeout = 10000L)
  public final void testRR() throws IllegalStateException, UnknownHostException {
    final ChunkStorageFactory factory = new ChunkStorageFactory();
    if (strategy.isRandom() == false) {
      // On teste uniquement le Hash
      return;
    }
    // Si on met 10 objets, on doit en avoir 5 sur chaque serveur
    String a = "value";
    Chunk aChunk = createChunk(a);
    String col_name = "dummy_test";
    ChunkStorage storage = createStorage(factory).start(col_name, new ServerAddress("localhost", 27017), new ServerAddress("localhost", 27018));
    for (int i = 0; i < 10; i++) {
      storage.add(aChunk);
    }
    storage.close();

    ChunkStorage first = factory.create().start(col_name, new ServerAddress("localhost", 27017));
    assertEquals(5, first.find(a).size());
    first.remove(aChunk);
    first.close();
    

    ChunkStorage second = factory.create().start(col_name, new ServerAddress("localhost", 27018));
    assertEquals(5, second.find(a).size());
    second.remove(aChunk);
    second.close();
  }
}
