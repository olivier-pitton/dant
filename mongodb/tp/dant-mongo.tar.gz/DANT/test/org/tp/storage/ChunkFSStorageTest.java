package org.tp.storage;

public class ChunkFSStorageTest extends AChunkStorage {

  @Override
  protected ChunkStorage createStorage(ChunkStorageFactory factory) {
    return factory.createFS();
  }

}
