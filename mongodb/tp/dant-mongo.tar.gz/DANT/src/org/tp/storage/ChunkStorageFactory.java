package org.tp.storage;

import org.tp.strategy.ChunkStrategy;

/**
 * Une factory de création de ChunkStorage.
 * @author pitton
 *
 */
public class ChunkStorageFactory {

  public ChunkStorageFactory() {
  }
  
  public ChunkStorage create() {
    return null;
  }
  
  public ChunkStorage createComposite(ChunkStrategy st) {
    return null;
  }

  public ChunkStorage createFS() {
    return null;
  }
  
}
