package org.tp.chunk;

/**
 * Une factory de création de chunk. Toute instanciation de chunk doit passer par cette classe.
 * @author pitton
 *
 */
public class ChunkFactory {

  public ChunkFactory() {
  }
  
  public Chunk create() {
    return null;
  }
  
  public Chunk create(String name, long id, long maxId, byte[] content) {
    return null;
  }

}
