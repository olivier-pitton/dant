package org.tp.chunk;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Une implémentation du pattern Builder pour les Chunks. Facilite la création
 * de chunks et permet de découper un fichier.
 * 
 * @author pitton
 * 
 */
public final class ChunkBuilder {

  private Chunk chunk;

  public ChunkBuilder() {
    chunk = new ChunkFactory().create();
  }

  public Chunk build() {
    return chunk;
  }

  public ChunkBuilder setName(String name) {
    chunk.setName(name);
    return this;
  }

  public ChunkBuilder setIds(long id, long maxId) {
    chunk.setId(id);
    chunk.setMaxId(maxId);
    return this;
  }

  public ChunkBuilder setContent(byte[] content) {
    chunk.setContent(content);
    return this;
  }

  static public List<Chunk> chunks(String filename, int nbSplit) throws IOException {
    File file = new File(filename);
    long size = file.length();
    List<Chunk> chunks = new ArrayList<Chunk>(nbSplit);
    int splitSize = (int) (size / nbSplit);
    byte[] content = new byte[(int) size];
    ChunkFactory factory = new ChunkFactory();
    FileInputStream fos = null;
    try {
      fos = new FileInputStream(file);
      fos.read(content);
    } finally {
      if (fos != null)
        fos.close();
    }
    for (int i = 0; i < nbSplit; i++) {
      chunks.add(factory.create(filename, i, nbSplit, Arrays.copyOfRange(content, i * splitSize, (i + 1) * splitSize)));
    }
    return chunks;
  }
}
