package org.tp.strategy;

import java.util.List;

import org.tp.storage.ChunkStorage;

/**
 * Cette interface sert à déterminer quel {@link ChunkStorage} doit être sélectionné pour effectuer une opération sur la base. 
 * Si un {@link ChunkStorage} est connecté à plusieurs serveurs, il peut utiliser des stratégies pour savoir quel serveur choisir. 
 * @author pitton
 *
 */
public interface ChunkStrategy {

  /**
   * Renvoie vrai si la stratégie de placement est aléatoire (comme le round-robin), faux sinon (comme le hachage)
   * @return vrai si la stratégie de placement est aléatoire 
   */
  boolean isRandom();
  
  /**
   * Sélectionne un {@link ChunkStorage} selon une stratégie depuis la liste spécifiée.
   * @param chunkName Le nom du chunk sur lequel on veut effectuer une opération
   * @param servers La liste des {@link ChunkStorage} que l'on possède
   * @return Le {@link ChunkStorage} sur lequel l'opération devra être effectuée.
   */
  ChunkStorage select(String chunkName, List<ChunkStorage> servers);
  
}
