package com.dant.storage;

import com.dant.chunk.Chunk;

import java.io.Closeable;
import java.util.List;

/**
 * L'interface de stockage des chunks dans une base NoSQL. Cette interface possédera plusieurs implémentations, comme indiqué dans le sujet de TP.
 * @author pitton
 *
 */
public interface ChunkStorage<T extends Chunk> extends Closeable {

  
  /**
   * Ferme la connexion au serveur NoSQL. <b>Cette méthode doit être thread-safe.</b>
   */
  @Override
  void close();

  
  /**
   * Sauvegarde le chunk spécifié dans la base NoSQL
   * @param chunk Le chunk à sauvegarder
   */
  void add(T chunk);
  
  /**
   * Sauvegarde les chunks spécifiés dans la base NoSQL
   * @param chunks Les chunks à sauvegarder
   */
  void add(List<T> chunks);
  
  /**
   * Supprime le chunk. Attention, cette méthode ne doit supprimer que ce chunk, et non le fichier entier.
   * @param chunk Le chunk à supprimer
   */
  void remove(T chunk);

  /**
   * Retourne le chunk dont le nom et l'identifiant ont été spécifiés.
   * @param name Le nom du chunk
   * @param id L'identifiant du chunk
   * @return Le chunk retrouvé, ou null s'il n'existe pas
   */
  T find(String name, long id);

  /**
   * Retourne la liste des chunks associés au nom de fichier donné.
   * @param name Un nom de fichier
   * @return La liste des chunks retrouvés
   */
  List<T> find(String name);
  
  /**
   * Renvoie le nombre de chunks présents sur le serveur
   * @return le nombre de chunks présents sur le serveur
   */
  long chunks();
 
}
