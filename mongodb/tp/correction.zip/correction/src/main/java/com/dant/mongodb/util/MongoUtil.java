package com.dant.mongodb.util;

import com.mongodb.MongoClient;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Morphia;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created by pitton on 2017-02-21.
 */
public class MongoUtil {

	public static Datastore getPrimaryNode() {
		return primary;
	}

	private static final Datastore primary = Init.instance(27017);

	private static class Init {

		public static Datastore instance(int port) {
			Morphia morphia = new Morphia();
			morphia.mapPackage("com.dant.mongodb.entity");
			Datastore datastore = morphia.createDatastore(new MongoClient("localhost", port), "ntw");
			datastore.ensureIndexes();
			return datastore;
		}
	}

	private MongoUtil() {}
}
