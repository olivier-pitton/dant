package com.dant.mongodb.entity;

import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.*;

import java.io.Serializable;

/**
 * Created by pitton on 2017-02-21.
 */
@Entity("account")
@Indexes(
		@Index(value = "email", fields = @Field("email"), unique = true)
)
public class Account implements Serializable {

	@Id
	private ObjectId _id;

	private String email;

	private long created = System.currentTimeMillis();

	public Account() {
	}

	public Account(String email) {
		this.email = email;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getCreated() {
		return created;
	}

	public void setCreated(long created) {
		this.created = created;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		Account account = (Account) o;

		return email.equals(account.email);
	}

	@Override
	public int hashCode() {
		return email.hashCode();
	}

	@Override
	public String toString() {
		return email;
	}
}
