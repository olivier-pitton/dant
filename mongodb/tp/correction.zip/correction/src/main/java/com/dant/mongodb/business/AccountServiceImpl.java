package com.dant.mongodb.business;

import com.dant.mongodb.entity.Account;
import com.dant.mongodb.util.MongoUtil;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.Query;

import java.util.List;

/**
 * Created by pitton on 2017-02-21.
 */
public class AccountServiceImpl implements AccountService {

	private final Datastore datastore = MongoUtil.ds;

	public Account save(String email) {
		Account account = new Account(email);
		datastore.save(account);
		return account;
	}

	public Account find(String email) {
		return datastore.createQuery(Account.class).filter("email", email).get();
	}

	public List<Account> findAll() {
		return datastore.createQuery(Account.class).asList();
	}

	public void remove(String email) {
		Query<Account> query = datastore.createQuery(Account.class).filter("email", email);
		datastore.delete(query);
	}
}
